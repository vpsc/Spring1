package com.cg.springmvcone.dto;

public class Product
{

	private int productID;
	private String productName;
	private String productType;
	private double productPrice;
	private String productOnline;
	
	public int getProductID() {
		return productID;
	}
	public void setProductID(int productID) {
		this.productID = productID;
	}
	
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	
	public double getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}

	public String getProductOnline() {
		return productOnline;
	}
	public void setProductOnline(String productOnline) {
		this.productOnline = productOnline;
	}
	
	
	@Override
	public String toString() {
		return "Product [productID=" + productID + ", productName="
				+ productName + ", productType=" + productType
				+ ", productPrice=" + productPrice + ", productOnline="
				+ productOnline + "]";
	}	
}

package com.cg.springmvcone.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.springmvcone.dto.Product;


@Controller
public class ProductController 
{
	@RequestMapping(value="add",method=RequestMethod.GET)
	public String addData(@ModelAttribute("my") Product pro) 		//we do this in order to transfer data from product to controller..where "my" is temporary variable where we storing the data
	{
		System.out.println("jjjjjj");
		return "addProduct";			//returning welcome page or we can say opening welcome page WHICH WE ALREADY DEFINE IN dispacher-servlet.xml part
	}
	
}

package com.capgemini.springmvctwo.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.springmvctwo.dto.Mobile;
import com.capgemini.springmvctwo.service.IMobileService;

@Controller
public class MobileController
{
	@Autowired
	IMobileService mobileservice;
	@RequestMapping(value="show",method=RequestMethod.GET)
	public ModelAndView getMobileDetails()
	{
		List<Mobile> showData=mobileservice.showAll();
		
		return new ModelAndView("mobileshow", "mob",showData);
		
	}

	@RequestMapping(value="delete",method=RequestMethod.GET)
	public String deleteMobile(@RequestParam("id") int mobId)
	{
			//System.out.println(mobId);	-to check that whether the method is working or not
		mobileservice.removeMobile(mobId);
		return "redirect:/show";			//calling the updated show all page again
		
	}


	@RequestMapping(value  = "update" , method = RequestMethod.GET )
	public String update(@RequestParam("id") int id ,Map<String,Object> model , @ModelAttribute("up")Mobile mob)
	{
		
		 mob = mobileservice.searchMobile(id);
		
		System.out.println("In controller "+mob);
		model.put("up",mob);
		return "updateList";
		
	}
	
	@RequestMapping(value = "putdata" , method = RequestMethod.POST)
	public String updateData(@ModelAttribute("up")Mobile mob)
	{
		mobileservice.updateMobile(mob);
		
		return "redirect:/show";
		
	}
}

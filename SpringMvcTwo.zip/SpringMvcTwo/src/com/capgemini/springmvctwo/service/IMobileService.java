package com.capgemini.springmvctwo.service;

import java.util.List;

import com.capgemini.springmvctwo.dto.Mobile;

public interface IMobileService 
{
	public List<Mobile> showAll();
	public void removeMobile(int mobi);
	public void  updateMobile(Mobile mob);
	public Mobile searchMobile(int MobileId);
}

package com.capgemini.springmvctwo.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.capgemini.springmvctwo.dto.Mobile;
@Repository("mobiledao")
public class MobileDaoImpl implements IMobileDao 
{

	@PersistenceContext
	EntityManager entitymanager;
	
	@Override
	public List<Mobile> showAll() {
		Query queryOne= entitymanager.createQuery("FROM Mobile");
		List<Mobile> allData=queryOne.getResultList();
		return allData;
	}

	@Override
	public void removeMobile(int mobileId)
	{
		Query queryTwo = entitymanager.createQuery("DELETE FROM Mobile WHERE mobileId=:mob_id");
		queryTwo.setParameter("mob_id", mobileId);	//setting the parameters
		queryTwo.executeUpdate();					//executing the query
		
	}


	@Override
	public void updateMobile(Mobile mob) {
		Query queryThree = entitymanager.createQuery("Update Mobile SET mobileName = :mob_name , mobilePrice = :mob_price , mobileBrand = :mob_brand where mobileId = :mob_id");
	    queryThree.setParameter("mob_id", mob.getMobileId());
	    queryThree.setParameter("mob_name", mob.getMobileName());
	    queryThree.setParameter("mob_brand", mob.getMobileBrand());
	    queryThree.setParameter("mob_price", mob.getMobilePrice());
	    queryThree.executeUpdate();
	    
	
	}

	@Override
	public Mobile searchMobile(int mobileId) {
		Query querFour = entitymanager.createQuery("From Mobile where mobileId=:mob_id");
		querFour.setParameter("mob_id", mobileId);
		Mobile mobList =(Mobile)querFour.getSingleResult();
		System.out.println(mobList);
			return mobList;
	}
	
}

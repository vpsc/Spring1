package com.capgemini.springmvctwo.dao;

import java.util.List;

import com.capgemini.springmvctwo.dto.Mobile;

public interface IMobileDao 
{

	public List<Mobile> showAll();
	public void removeMobile(int mobId);
	public void  updateMobile(Mobile mob);
	public Mobile searchMobile(int mobileId);
}

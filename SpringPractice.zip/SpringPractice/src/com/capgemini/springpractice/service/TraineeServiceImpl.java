package com.capgemini.springpractice.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.springpractice.dao.ITraineeDao;
import com.capgemini.springpractice.dto.Trainee;

@Service("traineeservice")
@Transactional
public class TraineeServiceImpl implements ITraineeService
{
	@Autowired
	ITraineeDao traineedao;

	@Override
	public int addTrainee(Trainee train) {
		
		return traineedao.addTrainee(train);
		
	}

	@Override
	public List<Trainee> deleteTrainee(int traineeId) {
		
		return traineedao.deleteTrainee(traineeId);
		
	}

	@Override
	public List<Trainee> showAll() {

		return traineedao.showAll();
	}

}

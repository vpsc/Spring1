package com.capgemini.springpractice.service;

import java.util.List;

import com.capgemini.springpractice.dto.Trainee;


public interface ITraineeService 
{
	
	public int addTrainee(Trainee train);
	public List<Trainee> deleteTrainee(int traineeId);
	public List<Trainee> showAll();
}

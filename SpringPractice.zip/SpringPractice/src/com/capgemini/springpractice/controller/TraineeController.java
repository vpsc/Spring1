package com.capgemini.springpractice.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.springpractice.dto.Trainee;
import com.capgemini.springpractice.service.ITraineeService;

@Controller
public class TraineeController
{

	@Autowired
	ITraineeService traineeservice;
	
	@RequestMapping(value="add", method=RequestMethod.GET)
	public String  insertTrainee(@ModelAttribute("my") Trainee trn,Map<String,Object> model)
	{
		List<String> myList = new ArrayList<String>();
		myList.add("Select");
		myList.add("Java");
		myList.add(".NET");
		myList.add("Testing");
		myList.add("SAP");
		myList.add("VNV");
		myList.add("BU");
		
		model.put("ptype", myList);
		
		
		return "addTrainee";
		
	}
	
	@RequestMapping(value="putdata",method=RequestMethod.POST)
	public ModelAndView add(@ModelAttribute("my") Trainee train)
	{
		
		int trainID = traineeservice.addTrainee(train);
		return new ModelAndView("success", "trainee", trainID);
		
		
	}
	
	@RequestMapping(value="delete",method=RequestMethod.GET)
	public String remove(@ModelAttribute("my")Trainee train)
	
	{
		
			return "deletetrainee";
		
	}
	
	@RequestMapping(value="delTrainee", method=RequestMethod.POST)
	public ModelAndView removeTrainee(@ModelAttribute("my")Trainee train)
	{
		int trainId = train.getTraineeId();
		List<Trainee> myList = traineeservice.deleteTrainee(trainId);
		return new ModelAndView("show", "showTrainee", myList);
		
		
	}
	
	
	
	@RequestMapping(value="showall",method=RequestMethod.GET)
	public ModelAndView show(@ModelAttribute("show")Trainee train)
	
	{
		
		List<Trainee> myList =  traineeservice.showAll();
		return new ModelAndView("show","showTrainee", myList);
		
	}

}




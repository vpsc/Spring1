package com.capgemini.springpractice.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.capgemini.springpractice.dto.Trainee;

@Repository("traineedao")

public class TraineeDaoImpl implements ITraineeDao
{

	@PersistenceContext
	EntityManager entitymanager;
	
	@Override
	public int addTrainee(Trainee train) 
	{
		
		entitymanager.persist(train);			
		entitymanager.flush();					
		return train.getTraineeId();
		
	}

	@Override
	public List<Trainee> deleteTrainee(int traineeId) {
		Query queryTwo = entitymanager.createQuery("FROM Trainee WHERE traineeId=:TRAINEEID");
		queryTwo.setParameter("TRAINEEID", traineeId);
		List<Trainee> myList = queryTwo.getResultList();
		
		
		Query queryThree = entitymanager.createQuery("DELETE FROM Trainee where traineeId=:TRAINEEID");
		queryThree.setParameter("TRAINEEID", traineeId);
		queryThree.executeUpdate();
		
		return myList;
	}

	@Override
	public List<Trainee> showAll() {
		Query queryFour = entitymanager.createQuery("FROM Trainee");
		List<Trainee> myList = queryFour.getResultList();
		return myList;
	}

}

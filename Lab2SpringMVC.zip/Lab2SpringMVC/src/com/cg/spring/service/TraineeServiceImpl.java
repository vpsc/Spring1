package com.cg.spring.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring.dao.ITraineeDao;
import com.cg.spring.dto.Trainee;

@Service("traineeservice")
@Transactional
public class TraineeServiceImpl implements ITraineeService {

	@Autowired
	ITraineeDao traineedao;
	
	
	@Override
	public int adddata(Trainee trn) {
		// TODO Auto-generated method stub
		
		return traineedao.adddata(trn);
	}





	@Override
	public List<Trainee> showData() {
		// TODO Auto-generated method stub
		return traineedao.showData();
	}


	@Override
	public List<Trainee> search(int id) {
		// TODO Auto-generated method stub
		return traineedao.search(id);
	}


	@Override
	public List<Trainee> remove(int id) {
		return traineedao.remove(id);
		
		
	}


	@Override
	public void update(Trainee trn) {
		traineedao.update(trn);
		
	}

	

}

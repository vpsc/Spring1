package com.cg.spring.service;

import java.util.List;

import com.cg.spring.dto.Trainee;

public interface ITraineeService {

public int adddata(Trainee trn);
	
	
public List<Trainee> showData();
	
	public List<Trainee> search(int id);
	public List<Trainee> remove(int id);
	public void update(Trainee trn);
}

package com.cg.spring.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.spring.dto.Trainee;
import com.cg.spring.service.ITraineeService;


@Controller

public class TraineeController {

	@Autowired
	ITraineeService traineeservice;
	
	//add
	@RequestMapping(value="add", method=RequestMethod.GET)
	public String add(@ModelAttribute("my") Trainee trn, Map<String,Object> model){
		
		
		List<String> myList = new ArrayList<String>();
		
		myList.add("JEE");

		myList.add("Testing");

		myList.add("DotNet");
		model.put("list",myList);
		return "addpage";
		
	}
	
	@RequestMapping(value="putdata", method=RequestMethod.POST)
	public ModelAndView adddata(@ModelAttribute("my") Trainee trn){
		
		
		int traineeid=traineeservice.adddata(trn);
		return new ModelAndView("success","trainee",traineeid);
		
	}
	
	//show
	@RequestMapping(value="showall",method=RequestMethod.GET)
	public ModelAndView show(@ModelAttribute("my") Trainee trn){
		
		List<Trainee> myList = traineeservice.showData();
		return new ModelAndView("show","traineeShow",myList);
		
	}
	
	
	//search
	@RequestMapping(value="search", method=RequestMethod.GET)
	public String search(@ModelAttribute("data") Trainee trn){
		
		
		return "searchid";
		
	}
	@RequestMapping(value="searchdata",method=RequestMethod.POST)
	public ModelAndView searchdata(@ModelAttribute("data") Trainee trn){
		int traineeid= trn.getTraineeId();
		
		List<Trainee> searchdata= traineeservice.search(traineeid);
		return new ModelAndView("show","traineeShow",searchdata);
		
	}
	
	//delete
	@RequestMapping(value="remove",method=RequestMethod.GET)
	public String delete(@ModelAttribute("data") Trainee trn){
		
		return "deleteid";
		
	}
	@RequestMapping(value="removedata",method=RequestMethod.POST)
	public ModelAndView removedata(@ModelAttribute("data") Trainee trn){
		int traineeid= trn.getTraineeId();
		
		List<Trainee> removedata= traineeservice.remove(traineeid);
		return new ModelAndView("show","traineeShow",removedata);
		
	}
	
	//update
	
	@RequestMapping(value="update", method=RequestMethod.GET)
	public String updateTrainee(@ModelAttribute("mysearch") Trainee trn)
	{
		return "updateid";
		
	}
	
	@RequestMapping(value="searchtrainee", method=RequestMethod.POST)
	public ModelAndView searchTrainee(@ModelAttribute("mysearch") Trainee trn, Map<String,Object> model)
	{

		List<String> myList= new ArrayList<String>();
		
		myList.add("Java");
		myList.add("Testing");
		myList.add("Mainframe");
		myList.add(".NET");
		
		model.put("tType", myList);
		
		int tranId = trn.getTraineeId();
		List<Trainee> mySearch = traineeservice.search(tranId);
		
		return new ModelAndView("update", "trainee", mySearch);
		
	}
	
	@RequestMapping(value ="putData" , method = RequestMethod.POST)
	public String updateData(@ModelAttribute("mysearch")Trainee trn)
	{
	traineeservice.update(trn);
		
		return "redirect:/Traniee.jsp";
		
	}
}

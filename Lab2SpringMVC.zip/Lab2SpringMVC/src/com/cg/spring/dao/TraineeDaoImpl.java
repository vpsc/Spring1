package com.cg.spring.dao;

import java.util.List;



import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.spring.dto.Trainee;

@Repository("traineedao")

public class TraineeDaoImpl implements ITraineeDao {

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public int adddata(Trainee trn) {
		// TODO Auto-generated method stub
		System.out.println(trn.getTraineeLocation());
		entityManager.persist(trn);
		entityManager.flush();
		return trn.getTraineeId();
		
		
	}

	

	@Override
	public List<Trainee> remove(int id) {
		
		Query queryThree=entityManager.createQuery("FROM Trainee where traineeId=:train_id");
		queryThree.setParameter("train_id", id);
		List<Trainee> myList = queryThree.getResultList();
		
		Query queryFour = entityManager.createQuery("DELETE FROM Trainee where traineeId=:train_id");
		queryFour.setParameter("train_id", id);
		queryFour.executeUpdate();
		
		return myList;
		
	
	}



	@Override
	public List<Trainee> showData() {
		// TODO Auto-generated method stub
		Query queryOne=entityManager.createQuery("FROM Trainee");
		
		List<Trainee> myList =queryOne.getResultList();
		
		
		
		
		return  myList;
	}



	@Override
	public List<Trainee> search(int id) {
		// TODO Auto-generated method stub
		
		Query queryTwo = entityManager.createQuery("FROM Trainee where traineeId=:train_id");
		queryTwo.setParameter("train_id", id);
		List<Trainee> myList = queryTwo.getResultList();
		
		
		return myList;
	}



	@Override
	public void update(Trainee trn) {
		Query queryFive = entityManager.createQuery("Update Trainee SET traineeName=:train_name,traineeDomain=:train_dom, traineeLocation=:train_loc where traineeId=:train_id");
		queryFive.setParameter("train_id", trn.getTraineeId());
		queryFive.setParameter("train_name", trn.getTraineeName());
		queryFive.setParameter("train_dom", trn.getTraineeDomain());
		queryFive.setParameter("train_loc", trn.getTraineeLocation());
		queryFive.executeUpdate();
		
		
		
		
	}

}

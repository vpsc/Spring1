package com.cg.spring.dao;

import java.util.List;

import com.cg.spring.dto.Trainee;

public interface ITraineeDao {

	
	
	public int adddata(Trainee trn);
	public List<Trainee> showData();
	
	public List<Trainee> search(int id);
	public List<Trainee> remove(int id);
	public void update(Trainee trn);
	
}

package com.capgemini.springformdemo.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.springformdemo.dto.Product;
import com.capgemini.springformdemo.service.IProductService;
@Controller
public class ProductController 
{

	
	@Autowired
	IProductService productservice;			//creating reference of service layer
	
	
	@RequestMapping(value="add",method=RequestMethod.GET)
	public String addData(@ModelAttribute("my")Product pro,
	Map<String,Object> model){ 		//we do this in order to transfer data from product to controller..where "my" is temporary variable where we storing the data
		List<String> myList = new ArrayList<String>();			//i map we are giving key and value pair key is in the string format and value is in the object format.we have done this thing in order to transfer the data from controller 
	
	
		myList.add("Electronics");
		myList.add("Grocery");
		myList.add("Home-Aplliances");
	
	
		model.put("ptype", myList);		//now this model will transfer to jsp page
		return "addProduct";			//returning welcome page or we can say opening welcome page WHICH WE ALREADY DEFINE IN dispacher-servlet.xml part
	}
	@RequestMapping(value="putdata",method=RequestMethod.POST)
	public ModelAndView dataAdd(@Valid@ModelAttribute("my")Product pro,BindingResult error,Map<String,Object> model)
	{
		
		if(error.hasErrors())		//condition for error
		{
			List<String> myList = new ArrayList<String>();			//i map we are giving key and value pair key is in the string format and value is in the object format.we have done this thing in order to transfer the data from controller 
			
			
			myList.add("Electronics");
			myList.add("Grocery");
			myList.add("Home-Aplliances");
		
		
			model.put("ptype", myList);		//now this model will transfer to jsp page
						
			return new ModelAndView("addProduct");
		}else
		{
			
		
		
		int prodId = productservice.insertData(pro);			//pro is what data coming from jsp part
		
		return new ModelAndView("sucess","pro",prodId);
		}
	}

	
	//method to show all
	@RequestMapping(value="showall",method=RequestMethod.GET)
	public ModelAndView dataShow() 
	{
		List<Product> allData = productservice.showData();				//list is added here because return type of showData method is list
		return new ModelAndView("prodshow", "mydata", allData);			//in order to transfer tha data to the jsp for display
	}																	//	view is the jsp which we are going to display the result		
	
	//model attribute is used to transfer the data between dao and jsp using help from controller
	//jsp>controller>dto>controller>jsp-----flow of data transfer using the help of model attribute
	
	@RequestMapping(value="search",method=RequestMethod.GET)
	public String searchPage(@ModelAttribute("data") Product pSearch)					//In order to open only view we will use String only
	{																				//for model+view we will use ModelAndView example is show all data
		return "prodsearch";
	}
	
	@RequestMapping(value="searchdata", method=RequestMethod.POST)
	public ModelAndView searchData(@ModelAttribute("data") Product pData) 
	{
		//System.out.println(pData.getProductID());
		int prodId = pData.getProductID();
		List<Product> searchData = productservice.searchData(prodId);
		return new ModelAndView("prodshow", "mydata", searchData);
		
	}
	
	@RequestMapping(value="remove",method=RequestMethod.GET)
	public String removePage(@ModelAttribute("data") Product pSearch)
	{
		return "prodremove";
		
	}
	
//	@RequestMapping(value="removeproduct", method=RequestMethod.POST)
//	public String removepage(@ModelAttribute("data") Product pDelete)
//	{
//		int prodId = pDelete.getProductID();
//		List<Product> removeData = productservice.
//	//	productservice.removeData(pDelete);
//	//	System.out.println("Product successfully removed");
////		return null;
	}
	


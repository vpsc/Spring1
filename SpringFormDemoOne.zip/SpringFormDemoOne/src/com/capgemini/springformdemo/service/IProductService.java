package com.capgemini.springformdemo.service;

import java.util.List;

import com.capgemini.springformdemo.dto.Product;

public interface IProductService 
{

	public int insertData(Product prod);
	public List<Product> showData();
	
	public List<Product> searchData(int prodId);
	public List<Product> removeData(int prodId);
}

package com.capgemini.springformdemo.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.springformdemo.dao.IProductDao;
import com.capgemini.springformdemo.dto.Product;

@Service("productservice")
@Transactional
public class ProductServiceImpl implements IProductService
{
	@Autowired
	IProductDao productdao;			//creating reference of dao layer

	@Override
	public int insertData(Product prod) 
	{
		
		return productdao.insertData(prod);
	}

	@Override
	public List<Product> showData() {
		
		return productdao.showData();
	}


	@Override
	public List<Product> searchData(int prodId) {
		
		return productdao.searchData(prodId)
				;
	}

	@Override
	public List<Product> removeData(int prodId) {
		// TODO Auto-generated method stub
		return null;
	}



}

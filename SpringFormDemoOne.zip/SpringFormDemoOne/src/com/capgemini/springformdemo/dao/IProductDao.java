package com.capgemini.springformdemo.dao;

import java.util.List;

import com.capgemini.springformdemo.dto.Product;

public interface IProductDao
{
	public int insertData(Product prod);
	public List<Product> showData();
	
	public List<Product> searchData(int prodID);
	public void removeData(Product pDelete);

}

package com.capgemini.springformdemo.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContexts;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestMapping;

import com.capgemini.springformdemo.dto.Product;
@Repository("productdao")				//where productdao is the name of the repository defined randomly by us which we will later use in controller to invoke it.
public class ProductDaoImpl implements IProductDao
{
	@PersistenceContext
	EntityManager entitymanager;

	@Override
	public int insertData(Product prod)
	{
		//inserting data inside table
		entitymanager.persist(prod);			//by using persist we will add data in the database 
		entitymanager.flush();					//whatever the temporary data it will go inside flush
		return prod.getProductID();
	}

	@Override
	public List<Product> showData()
	{
		Query queryOne=entitymanager.createQuery("FROM Product");				//we will not take the name of sql database we will take it from product class hence we will write it's reference
		List<Product> dataList = queryOne.getResultList();												//it is an example of dynamic query however the real query we will write in entity class
		return dataList;															
	}

	
	@Override
	public List<Product> searchData(int prodId)
	{
		Query queryTwo = entitymanager.createQuery("FROM Product WHERE productID=:prod_id");			//productID is the property name and prod_id is the column name we will use both of them simaltaenously  
		queryTwo.setParameter("prod_id", prodId);
		List<Product> mySearch=queryTwo.getResultList();
		return mySearch;
	}

	@Override
	public void removeData(Product pDelete) {
		entitymanager.remove(pDelete);
	}

}

package com.capgemini.springformdemo.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;


@Entity				//telling the controller that it is the class that we want to change or persist
@Table(name="PRODUCTDATA")
public class Product 
{
	@Id				//this is mandatory whenever we are using entity annotation can be used over variables to instead of setter
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="prodid")			//generated value is used in order to automatically generate id..method is generatedtype.sequence 
	@SequenceGenerator(name="prodid",sequenceName="prod_seq_id")			//prodid is just a reference value same should be given in both the above an lower statement
	@Column(name="prod_id")
														//use not null from validation.constraints class
	private int productID;			//@Id making product ID as primary key because it is during database operation
	@Column(name="prod_name")
	@NotEmpty(message="Product Name is required")
	@Size(min=3,max=20,message="minimum and maximum character should be between 3 and 20 characters")
	@Pattern(regexp="^[A-Z][a-z]$",message="Starting with capital")
	private String productName;
	@Column(name="prod_type")
	private String productType;
	@Column(name="prod_price")				//changing double to Double where double is primitive class and Double is wrapper class
	@NotNull(message="Price is required")
	private Double productPrice;
	@Column(name="prod_online")					//not null field is used for anything however for String e will write notEmpty 
	@NotEmpty(message="Online is required")
	private String productOnline;
	
	public int getProductID() 
	{
		return productID;
	}
	public void setProductID(int productID) 
	{
		this.productID = productID;
	}
	
	public String getProductName() 
	{
		return productName;
	}
	public void setProductName(String productName) 
	{
	
		this.productName = productName;
	}
	
	public String getProductType() 
	{
	
		return productType;
	}
	public void setProductType(String productType) 
	{
		this.productType = productType;
	}
	
	public Double getProductPrice() 
	{
		return productPrice;
	}
	public void setProductPrice(Double productPrice)
	{
		this.productPrice = productPrice;
	}

	public String getProductOnline() 
	{
		return productOnline;
	}
	public void setProductOnline(String productOnline) 
	{
		this.productOnline = productOnline;
	}
	
	
	@Override
	public String toString() {
		return "Product [productID=" + productID + ", productName="
				+ productName + ", productType=" + productType
				+ ", productPrice=" + productPrice + ", productOnline="
				+ productOnline + "]";
	}	
}
